#ifndef RUN_C
#define RUN_C

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "linkedlist.h"
#include "functions.h"
#include "simtimer.h"
#include "sim02_functions.h"


void run()
{
  
}


#endif // ifndef RUN_C
